package com.example.fragment;

public class Album {
    private String sName;
    private String sDetail;
    private String sPhotos;

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getsDetail() {
        return sDetail;
    }

    public void setsDetail(String sDetail) {
        this.sDetail = sDetail;
    }

    public String getsPhotos() {
        return sPhotos;
    }

    public void setsPhotos(String sPhotos) {
        this.sPhotos = sPhotos;
    }
}
