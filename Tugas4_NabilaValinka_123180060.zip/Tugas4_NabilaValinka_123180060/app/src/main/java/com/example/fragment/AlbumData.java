package com.example.fragment;

import java.util.ArrayList;

public class AlbumData {
    private static String[] albumTitles = {
            "Persona",
            "Maps Of The Soul"
    };

    private static String[] albumDesc = {
            "BTS",
            "BTS"
    };

    static ArrayList<Album> getlistData() {
        ArrayList<Album> list = new ArrayList<>();

        for (int position = 0; position < albumTitles.length; position++){
            Album album = new Album();
            album.setsName(albumTitles[position]);
            album.setsDetail((albumDesc[position]));
            list.add(album);
        }
        return list;
    }
}
